# Python image

The python image here is used by OS distros that don't have python installed to
run python scripts to parse the yaml files in the addon updater script.

[![Analytics](https://kubernetes-site.appspot.com/UA-36037335-10/GitHub/cluster/addons/python-image/README.md?pixel)]()
