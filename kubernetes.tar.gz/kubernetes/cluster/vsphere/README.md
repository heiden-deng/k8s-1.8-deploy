Please use [Kubernetes-anywhere](https://github.com/kubernetes/kubernetes-anywhere) to get started on vSphere.


[![Analytics](https://kubernetes-site.appspot.com/UA-36037335-10/GitHub/cluster/vsphere/README.md?pixel)]()
